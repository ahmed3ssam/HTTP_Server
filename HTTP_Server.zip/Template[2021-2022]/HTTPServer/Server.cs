﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace HTTPServer
{
    class Server
    {
        Socket serverSocket;

        public Server(int portNumber, string redirectionMatrixPath)
        {
            //TODO: call this.LoadRedirectionRules passing redirectionMatrixPath to it
            this.LoadRedirectionRules(redirectionMatrixPath);
            //TODO: initialize this.serverSocket
            this.serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint iPEnd = new IPEndPoint(IPAddress.Any, portNumber);
            this.serverSocket.Bind(iPEnd);

        }

        public void StartServer()
        {
            // TODO: Listen to connections, with large backlog.
            Console.WriteLine("Started......");
            // TODO: Accept connections in while loop and start a thread for each connection on function "Handle Connection"
            serverSocket.Listen(20000);
            
            while (true)
            {
                //TODO: accept connections and start thread for each accepted connection.
                Socket clientsocket = this.serverSocket.Accept();
                Console.WriteLine("Client accepted {0}", clientsocket.RemoteEndPoint);
                Thread newthread  = new Thread(new ParameterizedThreadStart(HandleConnection));
                newthread.Start(clientsocket);
            }
        }

        public void HandleConnection(object obj)
        {
            // TODO: Create client socket 
            Socket clientSock = (Socket)obj;
            Console.WriteLine("Accepted Connection");
            // set client socket ReceiveTimeout = 0 to indicate an infinite time-out period
            clientSock.ReceiveTimeout = 0;
            // TODO: receive requests in while true until remote client closes the socket.
            byte[] requestReceived = new byte[1024]; 
            
            while (true)
            {
                try
                {
                    // TODO: Receive request
                    int receivedLen = clientSock.Receive(requestReceived);
                    string receivedString = Encoding.ASCII.GetString(requestReceived, 0, receivedLen);
                    // TODO: break the while loop if receivedLen==0
                    if (receivedLen == 0)
                        {
                        Console.WriteLine("Client {0} ended Connection", clientSock.RemoteEndPoint);
                        break;
                         }
                    // TODO: Create a Request object using received request string
                    Request myrequest = new Request(receivedString);
                    // TODO: Call HandleRequest Method that returns the response
                    Response myresponse = HandleRequest(myrequest);
                    // TODO: Send Response back to client
                    string response_string = myresponse.ResponseString;
                }
                catch (Exception ex)
                {
                    // TODO: log exception using Logger class
                    Logger.LogException(ex);
                }
                clientSock.Close(); 
            }

            // TODO: close client socket
        }

        Response HandleRequest(Request request)
        {
            throw new NotImplementedException();
            string content;
            Response response;
            try
            {
                //TODO: check for bad request 
                if (request.ParseRequest() == false)
                {
                    content = LoadDefaultPage(Configuration.BadRequestDefaultPageName);
                    response = new Response(StatusCode.BadRequest, "text/html", content, null);
                    return response;
                }

                //TODO: map the relativeURI in request to get the physical path of the resource.

                //TODO: check for redirect
                if (Configuration.RedirectionRules.ContainsKey(request.relativeURI))
                {
                    string path = Configuration.RedirectionRules[request.relativeURI];
                    content = LoadDefaultPage(GetRedirectionPagePathIFExist(path));
                    response = new Response(StatusCode.Redirect, "text/html", content, path);
                    return response;
                }
                else
                {
                    content = LoadDefaultPage(request.relativeURI);
                    if (content != "") //TODO: check file exists
                    {
                        response = new Response(StatusCode.OK, "text/html", content, null);
                        return response;// Create OK response
                    }
                    else   
                    { 
                    content = LoadDefaultPage("NotFound.html");
                        response = new Response(StatusCode.NotFound, "text/html", content, null);
                        return response;
                    }
                     }
               

                //TODO: read the physical file

                
            }
            catch (Exception ex)
            {
                // TODO: log exception using Logger class
                Logger.LogException(ex);
                // TODO: in case of exception, return Internal Server Error. 
                content = LoadDefaultPage(Configuration.InternalErrorDefaultPageName);
                response = new Response(StatusCode.InternalServerError, "text/html", content, null);
                return response;
            }
        }

        private string GetRedirectionPagePathIFExist(string relativePath)
        {
            // using Configuration.RedirectionRules return the redirected page path if exists else returns empty
            string redirection_page_path = Configuration.RootPath + "\\" + relativePath;
            if (File.Exists(redirection_page_path))
            { return relativePath; }
            else
            { return string.Empty; }
        }

        private string LoadDefaultPage(string defaultPageName)
        {
            string filePath = Path.Combine(Configuration.RootPath, defaultPageName);
            // TODO: check if filepath not exist log exception using Logger class and return empty string
            StreamReader read_file;
            if (!File.Exists(filePath))
            {
                Exception e = new Exception("default page"+defaultPageName+ "doesn't exists");
                Logger.LogException(e);
                return String.Empty;
            }


            // else read file and return its content
            read_file = new StreamReader(filePath);
            string read = read_file.ReadToEnd();
           read_file.Close();
            return read;
        }

        private void LoadRedirectionRules(string filePath)
        {
            try
            {
                // TODO: using the filepath paramter read the redirection rules from file 
                StreamReader sr = new StreamReader(filePath);
                // then fill Configuration.RedirectionRules dictionary 
                Configuration.RedirectionRules = new Dictionary<string, string>();
                while (!sr.EndOfStream)
                    {
                string temp = sr.ReadLine();
                    string[] redirect = temp.Split(',');
                    Configuration.RedirectionRules.Add(redirect[0], redirect[1]);
                }

            }
            catch (Exception ex)
            {
                // TODO: log exception using Logger class
                Logger.LogException(ex);
                Environment.Exit(1);
            }
        }
    }
}
